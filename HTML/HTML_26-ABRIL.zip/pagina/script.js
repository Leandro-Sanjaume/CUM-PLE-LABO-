function ingreso(){
    var input1 = document.getElementById("1").value;
    var input2 = document.getElementById("2").value;
    var input3 = document.getElementById("3").value;
    var tablz = document.getElementById("tablitas");
    var row = document.createElement("tr");
    var data = document.createElement("td");
    var data2 = document.createElement("td");
    var data3 = document.createElement("td");
    tablz.append(row);
    row.append(data);
    row.append(data2);
    row.append(data3);
    data.append(input1);
    data2.append(input2);
    data3.append(input3);
    var disa = document.getElementById("ingreso");
    disa.classList.add("desapar");
    var disa2 = document.getElementById("inputis");
    disa2.classList.add("desapar");
    
}
function disappear(){
  
    var disa = document.getElementById("ingreso");
    disa.classList.remove("desapar");
    var disa2 = document.getElementById("inputis");
    disa2.classList.remove("desapar");
}
